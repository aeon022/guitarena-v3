import { Hono } from 'hono';
import { openPod } from '@a83/orbiter-core';
import { readFileSync, statSync } from 'fs';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';

const __dirname = dirname(fileURLToPath(import.meta.url));
const { version: adminVersion } = JSON.parse(
  readFileSync(join(__dirname, '../../package.json'), 'utf8')
);

import { allowedCollectionIds } from '../middleware/auth.js';

export const infoRoutes = new Hono();

// GET /api/info — pod path, format version, collection stats
infoRoutes.get('/', (c) => {
  const podPath = c.get('podPath');
  const db      = openPod(podPath);
  const allowed = allowedCollectionIds(db, c.get('user'));
  const cols    = db.getCollections().filter(col => !allowed || allowed.includes(col.id)).map(col => ({
    id:        col.id,
    label:     col.label,
    total:     db.getEntries(col.id, { status: 'published' }).length,
    drafts:    db.getEntries(col.id, { status: 'draft' }).length,
    scheduled: db.getEntries(col.id, { status: 'scheduled' }).length,
    review:    db.getEntries(col.id, { status: 'in_review' }).length,
    parent:    db.getMeta(`collection.${col.id}.parent`) ?? null,
    singleton: !!col.singleton,
  }));
  const version   = db.getMeta('format_version') ?? '1';
  const navHidden = db.getMeta('nav.hidden') ?? '';
  const navGroups = db.getMeta('nav.groups') ?? '';
  let navOrder = []; try { const o = JSON.parse(db.getMeta('nav.order') || '[]'); if (Array.isArray(o)) navOrder = o.filter(x => typeof x === 'string'); } catch {}
  db.close();
  let navGroupsParsed = null;
  try { navGroupsParsed = navGroups ? JSON.parse(navGroups) : null; } catch {}
  return c.json({
    podPath: c.get('user')?.role === 'admin' ? podPath : undefined, podSize: statSync(podPath).size, formatVersion: version, adminVersion, collections: cols,
    nav: {
      hidden: navHidden ? navHidden.split(',').map(s => s.trim()).filter(Boolean) : [],
      groups: navGroupsParsed,
      order: navOrder,
    },
  });
});
