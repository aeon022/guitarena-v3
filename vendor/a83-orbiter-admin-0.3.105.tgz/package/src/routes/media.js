import { Hono } from 'hono';
import { openPod, getMediaBackend, mediaResponseHeaders, parseVariant, renderVariant, useSharp } from '@a83/orbiter-core';
import { randomUUID } from 'node:crypto';
import sharp from 'sharp';
useSharp(sharp);
import { safeFetch } from '../net.js';
import { allowedCollectionIds } from '../middleware/auth.js';

const IMAGE_TYPES = new Set(['image/jpeg', 'image/png', 'image/webp', 'image/avif', 'image/tiff']);

async function optimizeImage(buffer, mimeType, db) {
  if (!IMAGE_TYPES.has(mimeType)) return { buffer, type: mimeType };
  const maxWidth    = parseInt(db.getMeta('media.img_max_width')    ?? '2400', 10);
  const quality     = parseInt(db.getMeta('media.img_quality')      ?? '85',   10);
  const convertWebp = db.getMeta('media.img_convert_webp') === '1';
  try {
    const img  = sharp(buffer);
    const meta = await img.metadata();
    if (meta.width && meta.width > maxWidth) img.resize({ width: maxWidth, withoutEnlargement: true });
    if (convertWebp && (mimeType === 'image/jpeg' || mimeType === 'image/png')) {
      return { buffer: await img.webp({ quality }).toBuffer(), type: 'image/webp' };
    }
    if (mimeType === 'image/jpeg') return { buffer: await img.jpeg({ quality, mozjpeg: true }).toBuffer(), type: mimeType };
    if (mimeType === 'image/png')  return { buffer: await img.png({ quality }).toBuffer(), type: mimeType };
    if (mimeType === 'image/webp') return { buffer: await img.webp({ quality }).toBuffer(), type: mimeType };
    if (mimeType === 'image/avif') return { buffer: await img.avif({ quality }).toBuffer(), type: mimeType };
    return { buffer: await img.toBuffer(), type: mimeType };
  } catch {
    return { buffer, type: mimeType };
  }
}

export const mediaRoutes = new Hono();

// GET /api/media?folder=
mediaRoutes.get('/', (c) => {
  const folder = c.req.query('folder') ?? null;
  const db     = openPod(c.get('podPath'));
  const items  = db.listMedia(folder);
  db.close();
  return c.json(items);
});

// GET /api/media/usage — where each file is referenced, which files are unused, which references are broken.
// References are found by media id inside entry data (that's how pickers and /orbiter/media/<id> URLs store them).
// Trashed entries count as references (they can be restored). Entries from collections the caller may not see are
// counted but never named.
const UUID_RE = /[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/g;
const MEDIA_URL_RE = /media\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})/g;
mediaRoutes.get('/usage', (c) => {
  const db = openPod(c.get('podPath'));
  const allowed = allowedCollectionIds(db, c.get('user'));
  const ids = new Set(db.db.prepare('SELECT id FROM _media').all().map(r => r.id));
  const usage = {};
  const broken = [];
  for (const e of db.db.prepare('SELECT collection_id, slug, data FROM _entries').all()) {
    const visible = !allowed || allowed.includes(e.collection_id);
    let title = e.slug; try { title = JSON.parse(e.data).title || e.slug; } catch {}
    for (const m of new Set(e.data.match(UUID_RE) ?? [])) {
      if (!ids.has(m)) continue;
      const u = (usage[m] ??= { count: 0, entries: [] });
      u.count++;
      if (visible) u.entries.push({ collection: e.collection_id, slug: e.slug, title });
    }
    if (visible) for (const [, m] of e.data.matchAll(MEDIA_URL_RE)) {
      if (!ids.has(m)) broken.push({ collection: e.collection_id, slug: e.slug, title, mediaId: m });
    }
  }
  db.close();
  return c.json({ usage, unused: [...ids].filter(id => !usage[id]), broken });
});

// GET /api/media/:id/raw  — serve binary or redirect to CDN
mediaRoutes.get('/:id/raw', async (c) => {
  const db      = openPod(c.get('podPath'));
  const item    = db.getMediaItem(c.req.param('id'));
  if (!item) { db.close(); return c.json({ error: 'Not found' }, 404); }

  // External backends: redirect to CDN/storage URL
  if (item.url) {
    db.close();
    return c.redirect(item.url, 302);
  }

  // Local backend reads from disk, default is the BLOB in SQLite
  let data = item.data;
  if (item.path) {
    const backend = getMediaBackend(db);
    const result  = await backend.get(item.id).catch(() => null);
    if (!result?.data) { db.close(); return c.json({ error: 'File not found on disk' }, 404); }
    data = result.data;
  }
  db.close();

  // ?w=&fmt=&ar= → resized / re-encoded / focal-point-cropped variant (see core media-variant.js)
  const variant = parseVariant(new URL(c.req.url).searchParams);
  if (variant) {
    try {
      const v = await renderVariant(item.id, data, item.mime_type, variant, { x: item.focal_x ?? undefined, y: item.focal_y ?? undefined });
      if (v) return new Response(v.data, { headers: { ...mediaResponseHeaders(v.type), 'Cache-Control': 'private, max-age=300' } });
    } catch (e) {
      if (e.code === 'BUSY') return c.json({ error: 'Busy, try again' }, 503);
      // not decodable → fall through to the original
    }
  }
  return new Response(data, { headers: mediaResponseHeaders(item.mime_type) });
});

// PUT /api/media/:id — alt text and/or focal point ({ focal_x, focal_y } in 0..1, or null to clear)
mediaRoutes.put('/:id', async (c) => {
  const body = await c.req.json().catch(() => ({}));
  const db   = openPod(c.get('podPath'));
  const item = db.getMediaItem(c.req.param('id'));
  if (!item) { db.close(); return c.json({ error: 'Not found' }, 404); }
  if ('alt' in body) db.db.prepare('UPDATE _media SET alt = ? WHERE id = ?').run(body.alt == null ? null : String(body.alt).slice(0, 500), item.id);
  if ('focal_x' in body || 'focal_y' in body) {
    const clear = body.focal_x == null && body.focal_y == null;
    const x = Number(body.focal_x), y = Number(body.focal_y);
    if (!clear && !(x >= 0 && x <= 1 && y >= 0 && y <= 1)) { db.close(); return c.json({ error: 'focal_x and focal_y must be between 0 and 1' }, 400); }
    db.setMediaFocal(item.id, clear ? null : x, clear ? null : y);
  }
  db.close();
  return c.json({ ok: true });
});

// POST /api/media  — multipart upload
mediaRoutes.post('/', async (c) => {
  const form   = await c.req.formData();
  const file   = form.get('file');
  const alt    = form.get('alt')?.toString()    ?? null;
  const folder = form.get('folder')?.toString() ?? '';

  if (!file || typeof file === 'string') return c.json({ error: 'No file provided' }, 400);

  const rawBuffer = Buffer.from(await file.arrayBuffer());
  const id        = randomUUID();
  const db        = openPod(c.get('podPath'));

  try {
    const { buffer, type: finalType } = await optimizeImage(rawBuffer, file.type, db);
    const finalName = finalType === 'image/webp' && file.type !== 'image/webp'
      ? file.name.replace(/\.[^.]+$/, '.webp')
      : file.name;
    const backend = getMediaBackend(db);
    await backend.upload(id, finalName, finalType, buffer.byteLength, buffer, alt, folder);
    const item    = db.getMediaItem(id);
    db.close();
    const { data: _, ...meta } = item;
    return c.json(meta, 201);
  } catch (err) {
    db.close();
    return c.json({ error: err.message }, 500);
  }
});

// POST /api/media/import-url  — server-side fetch from a public URL
mediaRoutes.post('/import-url', async (c) => {
  let body;
  try { body = await c.req.json(); } catch { return c.json({ error: 'Invalid JSON' }, 400); }
  let { url, alt, folder } = body;
  if (!url) return c.json({ error: 'No URL provided' }, 400);

  // Dropbox: convert share link to direct download
  if (/dropbox\.com/.test(url)) {
    url = url.replace(/[?&]dl=0/, '').replace(/(\?.*)$/, '$1&dl=1');
    if (!url.includes('?')) url += '?dl=1';
  }
  // Google Drive: convert /file/d/ID/view to direct download
  const gdrive = url.match(/drive\.google\.com\/file\/d\/([^/]+)/);
  if (gdrive) url = `https://drive.google.com/uc?export=download&id=${gdrive[1]}`;

  let resp, rawBuffer;
  try {
    ({ resp, buffer: rawBuffer } = await safeFetch(url, { headers: { 'User-Agent': 'Orbiter-Admin/1.0' } }));
  } catch (err) {
    return c.json({ error: `Fetch failed: ${err.message}` }, 400);
  }
  if (!resp.ok) return c.json({ error: `Remote returned ${resp.status}` }, 400);

  const mime      = (resp.headers.get('content-type') || 'application/octet-stream').split(';')[0].trim();
  const filename  = url.split('/').pop()?.split('?')[0] || 'imported';
  const id        = randomUUID();
  const db        = openPod(c.get('podPath'));

  try {
    const { buffer, type: finalType } = await optimizeImage(rawBuffer, mime, db);
    const finalName = finalType === 'image/webp' && mime !== 'image/webp'
      ? filename.replace(/\.[^.]+$/, '.webp')
      : filename;
    const backend = getMediaBackend(db);
    await backend.upload(id, finalName, finalType, buffer.byteLength, buffer, alt ?? null, folder ?? '');
    const item    = db.getMediaItem(id);
    db.close();
    const { data: _, ...meta } = item;
    return c.json(meta, 201);
  } catch (err) {
    db.close();
    return c.json({ error: err.message }, 500);
  }
});

// POST /api/media/add-link  — store an external URL reference, no data fetched
mediaRoutes.post('/add-link', async (c) => {
  let body;
  try { body = await c.req.json(); } catch { return c.json({ error: 'Invalid JSON' }, 400); }
  const { url, alt, folder, filename: providedName } = body;
  if (!url) return c.json({ error: 'No URL provided' }, 400);
  if (!/^https?:\/\//i.test(url)) return c.json({ error: 'Only http(s) URLs are allowed' }, 400);

  // Detect mime via HEAD request, fall back to extension sniffing
  let mime = 'application/octet-stream';
  try {
    const { resp: head } = await safeFetch(url, { method: 'HEAD', headers: { 'User-Agent': 'Orbiter-Admin/1.0' } });
    const ct = head.headers.get('content-type');
    if (ct) mime = ct.split(';')[0].trim();
  } catch {
    const ext = url.split('?')[0].split('.').pop()?.toLowerCase();
    const extMap = { jpg:'image/jpeg', jpeg:'image/jpeg', png:'image/png', gif:'image/gif',
                     webp:'image/webp', avif:'image/avif', svg:'image/svg+xml',
                     mp4:'video/mp4', webm:'video/webm', pdf:'application/pdf' };
    if (extMap[ext]) mime = extMap[ext];
  }

  const filename = providedName || url.split('/').pop()?.split('?')[0] || 'link';
  const id       = randomUUID();
  const db       = openPod(c.get('podPath'));
  db.insertMedia(id, filename, mime, 0, null, alt ?? null, folder ?? '', url, null);
  const item = db.getMediaItem(id);
  db.close();
  const { data: _, ...meta } = item;
  return c.json(meta, 201);
});

// DELETE /api/media/:id
mediaRoutes.delete('/:id', async (c) => {
  const db   = openPod(c.get('podPath'));
  const item = db.getMediaItem(c.req.param('id'));
  if (!item) { db.close(); return c.json({ error: 'Not found' }, 404); }

  try {
    const backend = getMediaBackend(db);
    await backend.delete(item.id);
    db.close();
    return c.json({ ok: true });
  } catch (err) {
    db.close();
    return c.json({ error: err.message }, 500);
  }
});
